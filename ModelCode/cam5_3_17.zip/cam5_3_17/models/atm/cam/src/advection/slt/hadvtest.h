common/savit/usave(plon,plev,plat), vsave(plon,plev,plat), pssave(plon,plat)
real(r8) usave, vsave, pssave
