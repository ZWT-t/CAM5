!
! $Id$
! $Author$
!
!
! Parameters common to many SLT routines
!
      integer ppdy              ! length of interpolation grid stencil
      logical plimdr            ! flag to limit derivatives
!
      parameter(ppdy = 4,  plimdr = .true.)
!
 
