#!/bin/sh
export LD_LIBRARY_PATH=/usr/local/netcdf-pgi/lib
/home/jshollen/cprnc_goldbach/cprnc.exe
